package com.spring.crudsystem.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.crudsystem.models.Usuario;
import com.spring.crudsystem.repository.CrudSystemRepository;

@Controller
public class CrudController {
	
	@Autowired
	private CrudSystemRepository csr;

	@RequestMapping(value="/cadastrarUsuario", method=RequestMethod.GET)
	public String cadastrarUsuario() {
		return "crud/cadastrar-usuario";
	}
	
	@RequestMapping(value="/cadastrarUsuario", method=RequestMethod.POST)
	public String cadastrarUsuario(Usuario usuario) {
		
		// Comando que realiza o cadastro do usuário no banco de dados
		csr.save(usuario);
		
		return "redirect:/";
	}
	
	@RequestMapping("/")
	public ModelAndView listarUsuarios() {
		ModelAndView mv = new ModelAndView("index");
		Iterable<Usuario> usuarios = csr.findAll();
		mv.addObject("usuarios", usuarios);
		return mv;
	}
	
	@RequestMapping("/atualizarUsuario")
	public String atualizarUsuario() {
		return "crud/atualizar-usuario";
	}
}
