function msgCadastro() {
    alert("Cadastro realizado com sucesso!");
}