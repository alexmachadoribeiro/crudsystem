package com.spring.crudsystem.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CrudController {

	@RequestMapping("/cadastrarUsuario")
	public String cadastrarUsuario() {
		return "crud/cadastrar-usuario";
	}
	
	@RequestMapping("/atualizarUsuario")
	public String atualizarUsuario() {
		return "crud/atualizar-usuario";
	}
}
