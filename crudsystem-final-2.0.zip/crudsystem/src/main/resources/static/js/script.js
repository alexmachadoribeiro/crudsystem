function msgConfimacao() {
    alert("Usuário cadastrado com sucesso!");
}

function msgAtualizacao() {
    alert("Usuário atualizado com sucesso!");
}

function msgExclusao() {
    alert("Usuário excluido com sucesso!");
}