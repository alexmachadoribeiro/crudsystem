package com.spring.crudsystem.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.crudsystem.models.Usuario;
import com.spring.crudsystem.repository.CrudSystemRepository;

@Controller
public class CrudController {
	
	@Autowired
	private CrudSystemRepository csr;

	@RequestMapping(value="/cadastrarUsuario", method=RequestMethod.GET)
	public String cadastrarUsuario() {
		return "crud/cadastrar-usuario";
	}
	
	@RequestMapping(value="/cadastrarUsuario", method=RequestMethod.POST)
	public String cadastrarUsuario(Usuario usuario) {
		csr.save(usuario);
		return "redirect:/";
	}
	
	@RequestMapping("/")
	public ModelAndView listarUsuarios() {
		ModelAndView mv = new ModelAndView("index");
		Iterable<Usuario> usuarios = csr.findAll();
		mv.addObject("usuarios", usuarios);
		return mv;
	}
	
	@RequestMapping("/alterarUsuario/{idUsuario}")
	public ModelAndView alterarUsuario(@PathVariable("idUsuario") long idUsuario) {
		Usuario usuario = csr.findByIdUsuario(idUsuario);
		ModelAndView mv = new ModelAndView("crud/atualizar-usuario");
		mv.addObject("usuario", usuario);
		return mv;
	}
	
	@RequestMapping("/confirmarExclusaoUsuario/{idUsuario}")
	public ModelAndView confirmarExclusaoUsuario(@PathVariable("idUsuario") long idUsuario) {
		Usuario usuario = csr.findByIdUsuario(idUsuario);
		ModelAndView mv = new ModelAndView("crud/excluir-usuario");
		mv.addObject("usuario", usuario);
		return mv;
	}
	
	@RequestMapping("/excluirUsuario")
	public String excluirUsuario(long idUsuario) {
		Usuario usuario = csr.findByIdUsuario(idUsuario);
		csr.delete(usuario);
		return "redirect:/";
	}
}
